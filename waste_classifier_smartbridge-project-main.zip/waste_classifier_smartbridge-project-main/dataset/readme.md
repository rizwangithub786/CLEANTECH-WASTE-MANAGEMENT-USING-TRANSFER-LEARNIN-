dataset i used to train the model
