powerpoint presentation of the project
