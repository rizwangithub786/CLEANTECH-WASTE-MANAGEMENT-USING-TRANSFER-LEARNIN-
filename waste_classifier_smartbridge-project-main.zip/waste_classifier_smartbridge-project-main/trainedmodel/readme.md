trained model using data set i created 
