# waste_classifier_smartbridge-project
This project aims to develop an intelligent system capable of automatically identifying and categorizing different types of waste materials,it also aims to sustainable development and resource conservation by making waste management.
